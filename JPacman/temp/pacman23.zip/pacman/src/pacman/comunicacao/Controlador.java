/*
 * File Controlador.java
 * Created on 15/10/2004
 * 
 */
package pacman.comunicacao;

/**
 * Class Controlador
 * @author Tiago Cordeiro Marques
 */
public interface Controlador {

}
